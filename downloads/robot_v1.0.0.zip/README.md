# Robot OTA更新程序

这是一个用于robot代码版本管理的OTA（Over-The-Air）更新程序，支持从hexo网站自动检查和更新代码版本。

## 功能特性

- 🔄 自动版本检查和更新
- 📦 压缩包下载和解压
- 💾 版本备份和回滚
- 📝 详细的日志记录
- ⚙️ 灵活的配置管理
- 🔒 文件校验和验证
- 📊 版本历史管理

## 文件结构

```
robot-client/
├── ota_updater.py          # OTA更新主程序
├── version_manager.py      # 版本管理器
├── ota_config.json         # OTA配置文件
├── version.json           # 当前版本信息
├── version_history.json   # 版本历史记录
├── backup/                # 备份目录
├── temp/                  # 临时文件目录
├── ota_update.log         # 更新日志
└── README.md             # 说明文档
```

## 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置hexo网站

在您的hexo网站中添加以下API端点：

#### 版本信息API (`/api/version`)
```json
{
  "version": "1.0.0",
  "build_date": "2024-01-15T10:30:00",
  "checksum": "sha256_checksum_here",
  "description": "新功能版本",
  "filename": "robot_v1.0.0.zip"
}
```

#### 下载路径
将robot代码压缩包放在hexo网站的 `/downloads/` 目录下。

### 3. 配置OTA程序

编辑 `ota_config.json` 文件：

```json
{
  "hexo_url": "http://192.168.139.134:4000",
  "version_api": "/api/version",
  "download_path": "/downloads",
  "check_interval": 3600,
  "backup_versions": 3,
  "timeout": 30,
  "verify_ssl": false
}
```

### 4. 运行OTA更新程序

```bash
# 手动检查更新
python ota_updater.py

# 或者作为服务运行
nohup python ota_updater.py &
```

## 使用说明

### 创建版本包

使用版本管理器创建版本包：

```bash
# 创建版本信息
python version_manager.py 1.0.0 -d "新功能版本"

# 创建版本包
python version_manager.py 1.0.0 -d "新功能版本" --create-package

# 指定输出路径
python version_manager.py 1.0.0 -d "新功能版本" --create-package -o /path/to/output.zip
```

### 配置参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `hexo_url` | hexo网站地址 | `http://192.168.139.134:4000` |
| `version_api` | 版本信息API端点 | `/api/version` |
| `download_path` | 下载路径 | `/downloads` |
| `check_interval` | 检查间隔（秒） | `3600` |
| `backup_versions` | 保留的备份版本数 | `3` |
| `timeout` | 请求超时时间 | `30` |
| `verify_ssl` | SSL验证 | `false` |

### 版本号格式

使用语义化版本号格式：`主版本号.次版本号.修订号`

例如：`1.0.0`, `1.1.0`, `1.1.1`

## 工作流程

1. **版本检查**: 程序启动时或定时检查远程版本信息
2. **版本比较**: 比较当前版本和远程版本
3. **下载更新**: 如果发现新版本，下载压缩包
4. **备份当前版本**: 更新前备份当前版本
5. **解压更新**: 解压新版本并替换文件
6. **验证更新**: 验证文件完整性和版本信息
7. **完成更新**: 更新版本信息并清理临时文件

## 安全特性

- **文件校验**: 使用SHA256校验和验证文件完整性
- **备份机制**: 更新前自动备份当前版本
- **回滚支持**: 支持回滚到之前的版本
- **错误恢复**: 更新失败时自动恢复

## 日志记录

所有操作都会记录到 `ota_update.log` 文件中，包括：

- 版本检查结果
- 下载进度
- 更新状态
- 错误信息

## 故障排除

### 常见问题

1. **连接失败**
   - 检查网络连接
   - 验证hexo_url配置
   - 检查防火墙设置

2. **下载失败**
   - 检查文件是否存在
   - 验证权限设置
   - 检查磁盘空间

3. **校验和不匹配**
   - 重新下载文件
   - 检查文件是否损坏
   - 验证远程校验和

### 手动恢复

如果自动更新失败，可以手动恢复：

```bash
# 查看备份版本
ls backup/

# 恢复特定版本
cp -r backup/backup_20240115_103000/* .

# 更新版本信息
python version_manager.py 1.0.0
```

## 扩展功能

### 自定义更新策略

可以通过修改 `ota_updater.py` 来实现自定义的更新策略：

- 增量更新
- 条件更新
- 定时更新
- 通知机制

### 集成到现有系统

OTA程序可以轻松集成到现有的robot系统中：

```python
from ota_updater import OTAManager

# 创建OTA管理器实例
ota = OTAManager()

# 检查更新
if ota.check_and_update():
    print("更新成功")
else:
    print("更新失败")
```

## 许可证

本项目采用MIT许可证。

## 贡献

欢迎提交Issue和Pull Request来改进这个项目。