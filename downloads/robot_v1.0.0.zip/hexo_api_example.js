/**
 * Hexo网站API示例
 * 用于提供robot版本信息的API端点
 * 
 * 使用方法：
 * 1. 将此文件放在hexo网站的scripts目录下
 * 2. 在hexo网站的public目录下创建api和downloads文件夹
 * 3. 运行hexo generate生成静态文件
 */

const fs = require('fs');
const path = require('path');

// 版本信息文件路径
const VERSION_FILE = path.join(__dirname, '../public/api/version.json');
const DOWNLOADS_DIR = path.join(__dirname, '../public/downloads');

hexo.extend.generator.register('api_generator', function(locals) {
  return [
    {
      path: 'api/version',
      data: function() {
        // 读取版本信息
        let versionInfo = {
          version: "1.0.0",
          build_date: new Date().toISOString(),
          checksum: "",
          description: "初始版本",
          filename: "robot_v1.0.0.zip"
        };

        try {
          if (fs.existsSync(VERSION_FILE)) {
            const content = fs.readFileSync(VERSION_FILE, 'utf8');
            versionInfo = JSON.parse(content);
          }
        } catch (error) {
          console.error('读取版本信息失败:', error);
        }

        return versionInfo;
      },
      layout: false
    }
  ];
});

// 创建必要的目录
hexo.on('ready', function() {
  const apiDir = path.join(__dirname, '../public/api');
  const downloadsDir = path.join(__dirname, '../public/downloads');

  if (!fs.existsSync(apiDir)) {
    fs.mkdirSync(apiDir, { recursive: true });
  }

  if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
  }

  // 创建默认版本信息文件
  const defaultVersion = {
    version: "1.0.0",
    build_date: new Date().toISOString(),
    checksum: "sha256_example_checksum_here",
    description: "初始版本",
    filename: "robot_v1.0.0.zip"
  };

  const versionFilePath = path.join(apiDir, 'version.json');
  if (!fs.existsSync(versionFilePath)) {
    fs.writeFileSync(versionFilePath, JSON.stringify(defaultVersion, null, 2));
    console.log('已创建默认版本信息文件:', versionFilePath);
  }
});

// 命令行工具
hexo.extend.console.register('version', '管理robot版本信息', {
  usage: '[command] [options]',
  arguments: [
    {name: 'command', desc: '命令: set, get, list'},
    {name: 'version', desc: '版本号 (用于set命令)'},
    {name: 'description', desc: '版本描述 (用于set命令)'}
  ]
}, function(args) {
  const command = args._.shift();
  
  switch (command) {
    case 'set':
      const version = args.version || args._.shift();
      const description = args.description || args._.shift() || '新版本';
      
      if (!version) {
        console.log('请指定版本号');
        return;
      }

      const versionInfo = {
        version: version,
        build_date: new Date().toISOString(),
        checksum: "sha256_checksum_here", // 这里应该计算实际的文件校验和
        description: description,
        filename: `robot_v${version}.zip`
      };

      try {
        fs.writeFileSync(VERSION_FILE, JSON.stringify(versionInfo, null, 2));
        console.log(`版本信息已更新: ${version}`);
      } catch (error) {
        console.error('更新版本信息失败:', error);
      }
      break;

    case 'get':
      try {
        if (fs.existsSync(VERSION_FILE)) {
          const content = fs.readFileSync(VERSION_FILE, 'utf8');
          const versionInfo = JSON.parse(content);
          console.log('当前版本信息:');
          console.log(JSON.stringify(versionInfo, null, 2));
        } else {
          console.log('版本信息文件不存在');
        }
      } catch (error) {
        console.error('读取版本信息失败:', error);
      }
      break;

    case 'list':
      try {
        if (fs.existsSync(DOWNLOADS_DIR)) {
          const files = fs.readdirSync(DOWNLOADS_DIR);
          console.log('可用的版本包:');
          files.forEach(file => {
            if (file.endsWith('.zip')) {
              const filePath = path.join(DOWNLOADS_DIR, file);
              const stats = fs.statSync(filePath);
              console.log(`  ${file} (${stats.size} bytes)`);
            }
          });
        } else {
          console.log('下载目录不存在');
        }
      } catch (error) {
        console.error('列出文件失败:', error);
      }
      break;

    default:
      console.log('可用命令:');
      console.log('  hexo version set <version> [description]  - 设置版本信息');
      console.log('  hexo version get                          - 获取当前版本信息');
      console.log('  hexo version list                         - 列出可用版本包');
      break;
  }
});

// 自动生成版本API的静态文件
hexo.extend.generator.register('version_api', function(locals) {
  return {
    path: 'api/version.json',
    data: function() {
      try {
        if (fs.existsSync(VERSION_FILE)) {
          const content = fs.readFileSync(VERSION_FILE, 'utf8');
          return JSON.parse(content);
        }
      } catch (error) {
        console.error('读取版本信息失败:', error);
      }
      
      return {
        version: "1.0.0",
        build_date: new Date().toISOString(),
        checksum: "",
        description: "初始版本",
        filename: "robot_v1.0.0.zip"
      };
    },
    layout: false
  };
});
