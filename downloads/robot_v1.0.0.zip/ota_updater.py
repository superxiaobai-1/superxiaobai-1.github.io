#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Robot OTA更新程序
用于从hexo网站检查和更新robot代码版本
"""

import os
import json
import time
import logging
import requests
import zipfile
import shutil
import hashlib
from pathlib import Path
from typing import Dict, Optional, Tuple
from datetime import datetime


class OTAManager:
    """OTA更新管理器"""
    
    def __init__(self, config_file: str = "ota_config.json"):
        """
        初始化OTA管理器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.current_dir = Path(__file__).parent
        self.version_file = self.current_dir / "version.json"
        self.backup_dir = self.current_dir / "backup"
        self.temp_dir = self.current_dir / "temp"
        
        # 创建必要的目录
        self.backup_dir.mkdir(exist_ok=True)
        self.temp_dir.mkdir(exist_ok=True)
        
        # 设置日志
        self._setup_logging()
        
        # 获取当前版本信息
        self.current_version = self._get_current_version()
        
    def _load_config(self) -> Dict:
        """加载配置文件"""
        default_config = {
            "hexo_url": "http://localhost:4000",  # hexo网站地址
            "version_api": "/api/version",  # 版本信息API端点
            "download_path": "/downloads",  # 下载路径
            "check_interval": 3600,  # 检查间隔（秒）
            "backup_versions": 3,  # 保留的备份版本数
            "timeout": 30,  # 请求超时时间
            "verify_ssl": False  # SSL验证
        }
        
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # 合并默认配置
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
            except Exception as e:
                logging.warning(f"加载配置文件失败: {e}，使用默认配置")
                return default_config
        else:
            # 创建默认配置文件
            self._save_config(default_config)
            return default_config
    
    def _save_config(self, config: Dict):
        """保存配置文件"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logging.error(f"保存配置文件失败: {e}")
    
    def _setup_logging(self):
        """设置日志"""
        log_file = self.current_dir / "ota_update.log"
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
    
    def _get_current_version(self) -> Dict:
        """获取当前版本信息"""
        if self.version_file.exists():
            try:
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logging.error(f"读取版本文件失败: {e}")
        
        # 返回默认版本信息
        default_version = {
            "version": "0.0.0",
            "build_date": datetime.now().isoformat(),
            "checksum": "",
            "description": "初始版本"
        }
        self._save_current_version(default_version)
        return default_version
    
    def _save_current_version(self, version_info: Dict):
        """保存当前版本信息"""
        try:
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump(version_info, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logging.error(f"保存版本文件失败: {e}")
    
    def _get_remote_version(self) -> Optional[Dict]:
        """从hexo网站获取最新版本信息"""
        try:
            url = f"{self.config['hexo_url']}{self.config['version_api']}"
            response = requests.get(
                url, 
                timeout=self.config['timeout'],
                verify=self.config['verify_ssl']
            )
            response.raise_for_status()
            
            version_info = response.json()
            logging.info(f"获取到远程版本信息: {version_info}")
            return version_info
            
        except requests.exceptions.RequestException as e:
            logging.error(f"获取远程版本信息失败: {e}")
            return None
        except json.JSONDecodeError as e:
            logging.error(f"解析版本信息JSON失败: {e}")
            return None
    
    def _compare_versions(self, version1: str, version2: str) -> int:
        """比较版本号
        
        Returns:
            -1: version1 < version2
             0: version1 == version2
             1: version1 > version2
        """
        def version_tuple(v):
            return tuple(map(int, v.split('.')))
        
        v1_tuple = version_tuple(version1)
        v2_tuple = version_tuple(version2)
        
        if v1_tuple < v2_tuple:
            return -1
        elif v1_tuple > v2_tuple:
            return 1
        else:
            return 0
    
    def _download_file(self, url: str, file_path: Path) -> bool:
        """下载文件"""
        try:
            logging.info(f"开始下载文件: {url}")
            response = requests.get(
                url,
                stream=True,
                timeout=self.config['timeout'],
                verify=self.config['verify_ssl']
            )
            response.raise_for_status()
            
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            logging.info(f"文件下载完成: {file_path}")
            return True
            
        except requests.exceptions.RequestException as e:
            logging.error(f"下载文件失败: {e}")
            return False
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """计算文件校验和"""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)
            return sha256_hash.hexdigest()
        except Exception as e:
            logging.error(f"计算校验和失败: {e}")
            return ""
    
    def _backup_current_version(self):
        """备份当前版本"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = self.backup_dir / f"backup_{timestamp}"
            
            # 复制当前代码到备份目录
            shutil.copytree(self.current_dir, backup_path, 
                          ignore=shutil.ignore_patterns(
                              '*.log', 'temp', 'backup', '__pycache__', '*.pyc'
                          ))
            
            logging.info(f"当前版本已备份到: {backup_path}")
            
            # 清理旧备份
            self._cleanup_old_backups()
            
        except Exception as e:
            logging.error(f"备份当前版本失败: {e}")
            raise
    
    def _cleanup_old_backups(self):
        """清理旧备份"""
        try:
            backups = list(self.backup_dir.glob("backup_*"))
            backups.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            
            # 保留最新的几个备份
            max_backups = self.config['backup_versions']
            for old_backup in backups[max_backups:]:
                shutil.rmtree(old_backup)
                logging.info(f"删除旧备份: {old_backup}")
                
        except Exception as e:
            logging.error(f"清理旧备份失败: {e}")
    
    def _extract_and_update(self, zip_path: Path) -> bool:
        """解压并更新代码"""
        try:
            # 创建临时解压目录
            extract_dir = self.temp_dir / "extract"
            if extract_dir.exists():
                shutil.rmtree(extract_dir)
            extract_dir.mkdir()
            
            # 解压文件
            logging.info(f"开始解压文件: {zip_path}")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # 找到解压后的代码目录
            extracted_dirs = [d for d in extract_dir.iterdir() if d.is_dir()]
            if not extracted_dirs:
                logging.error("解压后未找到代码目录")
                return False
            
            source_dir = extracted_dirs[0]  # 假设只有一个根目录
            
            # 排除不需要更新的文件和目录
            exclude_patterns = [
                'ota_config.json', 'version.json', 'ota_update.log',
                'temp', 'backup', '__pycache__'
            ]
            
            # 更新文件
            for item in source_dir.rglob('*'):
                if item.is_file():
                    # 检查是否在排除列表中
                    relative_path = item.relative_to(source_dir)
                    if any(pattern in str(relative_path) for pattern in exclude_patterns):
                        continue
                    
                    # 复制文件到目标位置
                    target_path = self.current_dir / relative_path
                    target_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, target_path)
            
            # 清理临时目录
            shutil.rmtree(extract_dir)
            zip_path.unlink()  # 删除下载的zip文件
            
            logging.info("代码更新完成")
            return True
            
        except Exception as e:
            logging.error(f"解压和更新代码失败: {e}")
            return False
    
    def check_and_update(self) -> bool:
        """检查并更新版本"""
        logging.info("开始检查版本更新...")
        
        # 获取远程版本信息
        remote_version_info = self._get_remote_version()
        if not remote_version_info:
            logging.error("无法获取远程版本信息")
            return False
        
        remote_version = remote_version_info.get('version', '0.0.0')
        current_version = self.current_version.get('version', '0.0.0')
        
        logging.info(f"当前版本: {current_version}")
        logging.info(f"远程版本: {remote_version}")
        
        # 比较版本
        if self._compare_versions(current_version, remote_version) >= 0:
            logging.info("当前版本已是最新版本，无需更新")
            return True
        
        logging.info(f"发现新版本 {remote_version}，开始更新...")
        
        # 备份当前版本
        self._backup_current_version()
        
        # 下载新版本
        download_url = f"{self.config['hexo_url']}{self.config['download_path']}/{remote_version_info['filename']}"
        zip_file_path = self.temp_dir / f"update_{remote_version}.zip"
        
        if not self._download_file(download_url, zip_file_path):
            logging.error("下载更新文件失败")
            return False
        
        # 验证文件校验和（如果提供）
        if 'checksum' in remote_version_info:
            calculated_checksum = self._calculate_checksum(zip_file_path)
            if calculated_checksum != remote_version_info['checksum']:
                logging.error("文件校验和不匹配，下载可能损坏")
                return False
        
        # 解压并更新代码
        if not self._extract_and_update(zip_file_path):
            logging.error("代码更新失败")
            return False
        
        # 更新版本信息
        self.current_version = {
            "version": remote_version,
            "build_date": remote_version_info.get('build_date', datetime.now().isoformat()),
            "checksum": remote_version_info.get('checksum', ''),
            "description": remote_version_info.get('description', ''),
            "update_date": datetime.now().isoformat()
        }
        self._save_current_version(self.current_version)
        
        logging.info(f"版本更新完成: {current_version} -> {remote_version}")
        return True
    
    def get_status(self) -> Dict:
        """获取OTA状态信息"""
        return {
            "current_version": self.current_version,
            "config": self.config,
            "last_check": datetime.now().isoformat()
        }


def main():
    """主函数"""
    print("Robot OTA更新程序启动...")
    
    ota_manager = OTAManager()
    
    try:
        # 检查并更新
        success = ota_manager.check_and_update()
        
        if success:
            print("OTA更新检查完成")
            status = ota_manager.get_status()
            print(f"当前版本: {status['current_version']['version']}")
        else:
            print("OTA更新检查失败，请查看日志文件")
            
    except KeyboardInterrupt:
        print("\n用户中断操作")
    except Exception as e:
        print(f"OTA更新程序异常: {e}")
        logging.error(f"OTA更新程序异常: {e}")


if __name__ == "__main__":
    main()
