# Robot OTA 部署指南 - 192.168.139.134:4000

本指南将帮助您在 `http://192.168.139.134:4000` 网站上部署Robot OTA更新系统。

## 🌐 网站配置

### 1. 网站地址配置
OTA程序已配置为连接到 `http://192.168.139.134:4000`

### 2. 需要的API端点

您的网站需要提供以下API端点：

#### 版本信息API: `http://192.168.139.134:4000/api/version`
返回JSON格式的版本信息：
```json
{
  "version": "1.0.0",
  "build_date": "2024-01-15T10:30:00",
  "checksum": "sha256_checksum_here",
  "description": "新功能版本",
  "filename": "robot_v1.0.0.zip"
}
```

#### 下载路径: `http://192.168.139.134:4000/downloads/`
用于存放robot代码压缩包的目录

## 📁 网站目录结构

您的网站需要以下目录结构：

```
192.168.139.134:4000/
├── api/
│   └── version.json          # 版本信息文件
├── downloads/                # 下载目录
│   ├── robot_v1.0.0.zip     # 版本包文件
│   ├── robot_v1.1.0.zip
│   └── ...
└── scripts/
    └── version_api.js        # API生成脚本
```

## 🚀 部署步骤

### 步骤1: 创建API目录和文件

在您的网站根目录下创建以下文件和目录：

```bash
# 创建API目录
mkdir -p api downloads scripts

# 创建版本信息文件
cat > api/version.json << 'EOF'
{
  "version": "1.0.0",
  "build_date": "2024-01-15T10:30:00",
  "checksum": "sha256_example_checksum_here",
  "description": "初始版本",
  "filename": "robot_v1.0.0.zip"
}
EOF
```

### 步骤2: 部署API生成脚本

将 `hexo_api_example.js` 文件复制到您的网站的 `scripts/` 目录，并根据需要修改。

### 步骤3: 上传版本包

将robot代码压缩包上传到 `downloads/` 目录：

```bash
# 示例：上传版本包
cp robot_v1.0.0.zip /path/to/your/website/downloads/
```

### 步骤4: 更新版本信息

当有新版本时，更新 `api/version.json` 文件：

```json
{
  "version": "1.1.0",
  "build_date": "2024-01-20T15:45:00",
  "checksum": "实际的sha256校验和",
  "description": "修复bug和新增功能",
  "filename": "robot_v1.1.0.zip"
}
```

## 🔧 自动化部署脚本

创建一个自动化脚本来简化版本发布：

```bash
#!/bin/bash
# deploy_version.sh

VERSION=$1
DESCRIPTION=$2
PACKAGE_FILE=$3

if [ -z "$VERSION" ] || [ -z "$PACKAGE_FILE" ]; then
    echo "用法: $0 <版本号> <描述> <包文件>"
    echo "示例: $0 1.1.0 '新功能版本' robot_v1.1.0.zip"
    exit 1
fi

# 计算文件校验和
CHECKSUM=$(sha256sum "$PACKAGE_FILE" | cut -d' ' -f1)

# 创建版本信息
cat > api/version.json << EOF
{
  "version": "$VERSION",
  "build_date": "$(date -u +%Y-%m-%dT%H:%M:%S)",
  "checksum": "$CHECKSUM",
  "description": "$DESCRIPTION",
  "filename": "$PACKAGE_FILE"
}
EOF

# 复制包文件到下载目录
cp "$PACKAGE_FILE" downloads/

echo "版本 $VERSION 已部署到网站"
echo "校验和: $CHECKSUM"
```

使用方法：
```bash
chmod +x deploy_version.sh
./deploy_version.sh 1.1.0 "新功能版本" robot_v1.1.0.zip
```

## 🧪 测试部署

### 测试API端点

```bash
# 测试版本信息API
curl https://code-bai.com/api/version

# 测试下载链接
curl -I https://code-bai.com/downloads/robot_v1.0.0.zip
```

### 测试OTA程序

```bash
# 在robot设备上测试
cd /home/robot/test_blog/robot-client
python start_ota.py check
```

## 📋 版本发布流程

1. **准备版本包**
   ```bash
   python version_manager.py 1.1.0 -d "新功能版本" --create-package
   ```

2. **上传到网站**
   ```bash
   ./deploy_version.sh 1.1.0 "新功能版本" robot_v1.1.0.zip
   ```

3. **验证部署**
   ```bash
   curl https://code-bai.com/api/version
   ```

4. **测试更新**
   ```bash
   python start_ota.py check
   ```

## 🔒 安全注意事项

1. **HTTPS**: 确保网站使用HTTPS，OTA程序已配置SSL验证
2. **文件校验**: 每次发布版本时都要计算并验证SHA256校验和
3. **备份**: 保留多个版本的备份文件
4. **访问控制**: 考虑对下载目录进行访问控制

## 🐛 故障排除

### 常见问题

1. **API无法访问**
   - 检查文件权限
   - 确认Web服务器配置
   - 验证SSL证书

2. **下载失败**
   - 检查文件是否存在
   - 验证文件权限
   - 确认网络连接

3. **校验和不匹配**
   - 重新计算文件校验和
   - 检查文件是否完整下载

### 调试命令

```bash
# 检查API响应
curl -v https://code-bai.com/api/version

# 检查文件下载
wget -O test.zip https://code-bai.com/downloads/robot_v1.0.0.zip

# 验证校验和
sha256sum test.zip
```

## 📞 支持

如果遇到问题，请检查：
1. 网站日志
2. OTA程序日志 (`ota_update.log`)
3. 网络连接状态
4. 文件权限设置
