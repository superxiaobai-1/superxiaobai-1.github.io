#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
连接测试脚本
测试与code-bai.com网站的连接
"""

import requests
import json
import sys
from pathlib import Path


def test_website_connection():
    """测试网站连接"""
    base_url = "http://192.168.139.134:4000"
    
    print("=== 测试与192.168.139.134:4000的连接 ===")
    
    # 测试基本连接
    try:
        print(f"1. 测试基本连接: {base_url}")
        response = requests.get(base_url, timeout=10, verify=False)
        print(f"   状态码: {response.status_code}")
        print(f"   响应时间: {response.elapsed.total_seconds():.2f}秒")
        
        if response.status_code == 200:
            print("   ✅ 基本连接成功")
        else:
            print(f"   ❌ 基本连接失败: {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ 连接失败: {e}")
        return False
    
    # 测试版本API
    try:
        print(f"2. 测试版本API: {base_url}/api/version")
        response = requests.get(f"{base_url}/api/version", timeout=10, verify=False)
        print(f"   状态码: {response.status_code}")
        
        if response.status_code == 200:
            try:
                version_info = response.json()
                print("   ✅ 版本API连接成功")
                print(f"   当前版本: {version_info.get('version', 'N/A')}")
                print(f"   版本描述: {version_info.get('description', 'N/A')}")
                print(f"   文件名: {version_info.get('filename', 'N/A')}")
                
                # 验证版本信息格式
                required_fields = ['version', 'build_date', 'checksum', 'filename']
                missing_fields = [field for field in required_fields if field not in version_info]
                
                if missing_fields:
                    print(f"   ⚠️  缺少必要字段: {missing_fields}")
                else:
                    print("   ✅ 版本信息格式正确")
                    
            except json.JSONDecodeError as e:
                print(f"   ❌ JSON解析失败: {e}")
                return False
        else:
            print(f"   ❌ 版本API连接失败: {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ 版本API连接失败: {e}")
        return False
    
    # 测试下载链接
    try:
        print(f"3. 测试下载链接: {base_url}/downloads/")
        response = requests.head(f"{base_url}/downloads/", timeout=10, verify=False)
        print(f"   状态码: {response.status_code}")
        
        if response.status_code in [200, 301, 302]:
            print("   ✅ 下载目录可访问")
        else:
            print(f"   ⚠️  下载目录访问异常: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"   ⚠️  下载目录测试失败: {e}")
    
    return True


def test_ota_config():
    """测试OTA配置"""
    print("\n=== 测试OTA配置 ===")
    
    config_file = Path(__file__).parent / "ota_config.json"
    
    if not config_file.exists():
        print("❌ 配置文件不存在")
        return False
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        print("✅ 配置文件加载成功")
        print(f"   Hexo URL: {config.get('hexo_url', 'N/A')}")
        print(f"   版本API: {config.get('version_api', 'N/A')}")
        print(f"   下载路径: {config.get('download_path', 'N/A')}")
        print(f"   检查间隔: {config.get('check_interval', 'N/A')}秒")
        print(f"   SSL验证: {config.get('verify_ssl', 'N/A')}")
        
        # 检查配置是否正确
        expected_url = "http://192.168.139.134:4000"
        if config.get('hexo_url') == expected_url:
            print("✅ URL配置正确")
        else:
            print(f"⚠️  URL配置可能不正确，期望: {expected_url}")
        
        return True
        
    except Exception as e:
        print(f"❌ 配置文件读取失败: {e}")
        return False


def test_version_file():
    """测试版本文件"""
    print("\n=== 测试版本文件 ===")
    
    version_file = Path(__file__).parent / "version.json"
    
    if not version_file.exists():
        print("❌ 版本文件不存在")
        return False
    
    try:
        with open(version_file, 'r', encoding='utf-8') as f:
            version_info = json.load(f)
        
        print("✅ 版本文件加载成功")
        print(f"   当前版本: {version_info.get('version', 'N/A')}")
        print(f"   构建日期: {version_info.get('build_date', 'N/A')}")
        print(f"   文件数量: {version_info.get('file_count', 'N/A')}")
        
        return True
        
    except Exception as e:
        print(f"❌ 版本文件读取失败: {e}")
        return False


def test_ota_manager():
    """测试OTA管理器"""
    print("\n=== 测试OTA管理器 ===")
    
    try:
        from ota_updater import OTAManager
        
        ota_manager = OTAManager()
        print("✅ OTA管理器初始化成功")
        
        # 测试获取远程版本信息
        print("正在获取远程版本信息...")
        remote_version = ota_manager._get_remote_version()
        
        if remote_version:
            print("✅ 成功获取远程版本信息")
            print(f"   远程版本: {remote_version.get('version', 'N/A')}")
        else:
            print("⚠️  无法获取远程版本信息")
        
        return True
        
    except ImportError as e:
        print(f"❌ 导入OTA管理器失败: {e}")
        return False
    except Exception as e:
        print(f"❌ OTA管理器测试失败: {e}")
        return False


def main():
    """主函数"""
    print("Robot OTA 连接测试工具")
    print("=" * 50)
    
    success_count = 0
    total_tests = 4
    
    # 测试网站连接
    if test_website_connection():
        success_count += 1
    
    # 测试OTA配置
    if test_ota_config():
        success_count += 1
    
    # 测试版本文件
    if test_version_file():
        success_count += 1
    
    # 测试OTA管理器
    if test_ota_manager():
        success_count += 1
    
    # 输出总结
    print("\n" + "=" * 50)
    print(f"测试完成: {success_count}/{total_tests} 项测试通过")
    
    if success_count == total_tests:
        print("🎉 所有测试通过！OTA系统配置正确")
        return 0
    else:
        print("⚠️  部分测试失败，请检查配置")
        return 1


if __name__ == "__main__":
    sys.exit(main())
