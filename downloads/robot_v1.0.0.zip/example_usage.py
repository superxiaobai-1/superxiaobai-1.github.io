#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OTA使用示例
演示如何使用OTA更新程序
"""

import os
import sys
import time
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, str(Path(__file__).parent))

from ota_updater import OTAManager
from version_manager import VersionManager


def example_create_version():
    """示例：创建版本"""
    print("=== 创建版本示例 ===")
    
    version_manager = VersionManager()
    
    # 创建版本信息
    version_info = version_manager.create_version_info(
        version="1.0.0",
        description="第一个正式版本"
    )
    
    print(f"版本信息:")
    print(f"  版本号: {version_info['version']}")
    print(f"  文件数量: {version_info['file_count']}")
    print(f"  总大小: {version_info['total_size']} bytes")
    print(f"  校验和: {version_info['checksum']}")
    
    # 保存版本信息
    version_manager.save_version_info(version_info)
    
    # 创建版本包
    package_path = version_manager.create_package(version_info)
    if package_path:
        print(f"版本包已创建: {package_path}")


def example_check_update():
    """示例：检查更新"""
    print("\n=== 检查更新示例 ===")
    
    ota_manager = OTAManager()
    
    # 显示当前状态
    status = ota_manager.get_status()
    print(f"当前版本: {status['current_version']['version']}")
    print(f"配置的Hexo URL: {status['config']['hexo_url']}")
    
    # 检查更新
    print("正在检查更新...")
    success = ota_manager.check_and_update()
    
    if success:
        print("更新检查完成")
        status = ota_manager.get_status()
        print(f"当前版本: {status['current_version']['version']}")
    else:
        print("更新检查失败")


def example_version_history():
    """示例：查看版本历史"""
    print("\n=== 版本历史示例 ===")
    
    version_manager = VersionManager()
    history = version_manager.get_version_history()
    
    if history:
        print(f"版本历史 (共{len(history)}个版本):")
        for i, version_info in enumerate(history):
            print(f"  {i+1}. {version_info['version']} - {version_info.get('description', '')}")
    else:
        print("没有版本历史记录")


def example_backup_info():
    """示例：查看备份信息"""
    print("\n=== 备份信息示例 ===")
    
    ota_manager = OTAManager()
    backup_dir = ota_manager.backup_dir
    
    if backup_dir.exists():
        backups = list(backup_dir.glob("backup_*"))
        if backups:
            print(f"可用备份 (共{len(backups)}个):")
            for backup in backups:
                stat = backup.stat()
                mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_mtime))
                print(f"  {backup.name} ({mtime})")
        else:
            print("没有找到备份")
    else:
        print("备份目录不存在")


def example_configuration():
    """示例：配置管理"""
    print("\n=== 配置管理示例 ===")
    
    ota_manager = OTAManager()
    config = ota_manager.config
    
    print("当前配置:")
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # 修改配置示例
    print("\n修改配置示例:")
    config['check_interval'] = 1800  # 30分钟
    config['backup_versions'] = 5
    ota_manager._save_config(config)
    print("配置已更新")


def main():
    """主函数"""
    print("Robot OTA更新程序使用示例")
    print("=" * 50)
    
    try:
        # 创建版本示例
        example_create_version()
        
        # 检查更新示例
        example_check_update()
        
        # 版本历史示例
        example_version_history()
        
        # 备份信息示例
        example_backup_info()
        
        # 配置管理示例
        example_configuration()
        
        print("\n示例运行完成！")
        
    except Exception as e:
        print(f"示例运行失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
