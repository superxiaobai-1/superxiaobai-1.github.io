#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hexo网站API设置脚本
帮助在hexo网站上快速设置OTA所需的API端点
"""

import os
import json
from pathlib import Path


def create_api_files():
    """创建API相关文件"""
    
    print("=== 创建Hexo API文件 ===")
    
    # 创建API目录结构
    api_dir = Path("hexo_api")
    api_dir.mkdir(exist_ok=True)
    
    # 1. 创建版本信息API文件
    version_api_content = '''---
title: Robot版本信息API
date: 2024-01-01 00:00:00
layout: false
---
{
  "version": "1.0.0",
  "build_date": "2024-01-15T10:30:00",
  "checksum": "sha256_example_checksum_here",
  "description": "初始版本",
  "filename": "robot_v1.0.0.zip"
}'''
    
    version_file = api_dir / "version.md"
    with open(version_file, 'w', encoding='utf-8') as f:
        f.write(version_api_content)
    print(f"✅ 已创建版本API文件: {version_file}")
    
    # 2. 创建下载目录说明
    downloads_readme = '''# Robot下载目录

此目录用于存放robot代码压缩包。

## 文件命名规则
- 格式: `robot_v{版本号}.zip`
- 示例: `robot_v1.0.0.zip`, `robot_v1.1.0.zip`

## 上传步骤
1. 使用版本管理器创建版本包
2. 将zip文件上传到此目录
3. 更新 `/api/version` 中的版本信息

## 注意事项
- 确保文件名与version.json中的filename字段一致
- 建议保留多个版本的备份文件
'''
    
    downloads_readme_file = api_dir / "downloads_readme.md"
    with open(downloads_readme_file, 'w', encoding='utf-8') as f:
        f.write(downloads_readme)
    print(f"✅ 已创建下载目录说明: {downloads_readme_file}")
    
    # 3. 创建部署脚本
    deploy_script = '''#!/bin/bash
# deploy_robot_version.sh - Robot版本部署脚本

VERSION=$1
DESCRIPTION=$2
PACKAGE_FILE=$3

if [ -z "$VERSION" ] || [ -z "$PACKAGE_FILE" ]; then
    echo "用法: $0 <版本号> <描述> <包文件>"
    echo "示例: $0 1.1.0 '新功能版本' robot_v1.1.0.zip"
    exit 1
fi

# 检查包文件是否存在
if [ ! -f "$PACKAGE_FILE" ]; then
    echo "错误: 包文件不存在: $PACKAGE_FILE"
    exit 1
fi

# 计算文件校验和
CHECKSUM=$(sha256sum "$PACKAGE_FILE" | cut -d' ' -f1)

# 创建版本信息JSON
cat > source/api/version.md << EOF
---
title: Robot版本信息API
date: $(date -u +%Y-%m-%dT%H:%M:%S)
layout: false
---
{
  "version": "$VERSION",
  "build_date": "$(date -u +%Y-%m-%dT%H:%M:%S)",
  "checksum": "$CHECKSUM",
  "description": "$DESCRIPTION",
  "filename": "$PACKAGE_FILE"
}
EOF

# 创建下载目录（如果不存在）
mkdir -p source/downloads

# 复制包文件到下载目录
cp "$PACKAGE_FILE" source/downloads/

echo "版本 $VERSION 已部署"
echo "校验和: $CHECKSUM"
echo "请运行 'hexo generate' 生成静态文件"
'''
    
    deploy_script_file = api_dir / "deploy_robot_version.sh"
    with open(deploy_script_file, 'w', encoding='utf-8') as f:
        f.write(deploy_script)
    
    # 设置执行权限
    os.chmod(deploy_script_file, 0o755)
    print(f"✅ 已创建部署脚本: {deploy_script_file}")
    
    # 4. 创建Hexo插件
    hexo_plugin = '''/**
 * Hexo Robot OTA API 插件
 * 自动生成Robot版本信息API
 */

const fs = require('fs');
const path = require('path');

hexo.extend.generator.register('robot_api', function(locals) {
  const apiDir = path.join(hexo.source_dir, 'api');
  
  return [
    {
      path: 'api/version.json',
      data: function() {
        // 读取版本信息
        const versionFile = path.join(apiDir, 'version.json');
        let versionInfo = {
          version: "1.0.0",
          build_date: new Date().toISOString(),
          checksum: "",
          description: "初始版本",
          filename: "robot_v1.0.0.zip"
        };

        if (fs.existsSync(versionFile)) {
          try {
            const content = fs.readFileSync(versionFile, 'utf8');
            versionInfo = JSON.parse(content);
          } catch (error) {
            console.error('读取版本信息失败:', error);
          }
        }

        return versionInfo;
      },
      layout: false
    }
  ];
});

// 命令行工具
hexo.extend.console.register('robot-version', '管理Robot版本信息', {
  usage: '[command] [options]',
  arguments: [
    {name: 'command', desc: '命令: set, get'},
    {name: 'version', desc: '版本号'},
    {name: 'description', desc: '版本描述'}
  ]
}, function(args) {
  const command = args._.shift();
  const versionFile = path.join(hexo.source_dir, 'api', 'version.json');
  
  switch (command) {
    case 'set':
      const version = args.version || args._.shift();
      const description = args.description || args._.shift() || '新版本';
      
      if (!version) {
        console.log('请指定版本号');
        return;
      }

      const versionInfo = {
        version: version,
        build_date: new Date().toISOString(),
        checksum: "sha256_checksum_here",
        description: description,
        filename: `robot_v${version}.zip`
      };

      try {
        // 确保目录存在
        const apiDir = path.dirname(versionFile);
        if (!fs.existsSync(apiDir)) {
          fs.mkdirSync(apiDir, { recursive: true });
        }
        
        fs.writeFileSync(versionFile, JSON.stringify(versionInfo, null, 2));
        console.log(`版本信息已更新: ${version}`);
      } catch (error) {
        console.error('更新版本信息失败:', error);
      }
      break;

    case 'get':
      try {
        if (fs.existsSync(versionFile)) {
          const content = fs.readFileSync(versionFile, 'utf8');
          const versionInfo = JSON.parse(content);
          console.log('当前版本信息:');
          console.log(JSON.stringify(versionInfo, null, 2));
        } else {
          console.log('版本信息文件不存在');
        }
      } catch (error) {
        console.error('读取版本信息失败:', error);
      }
      break;

    default:
      console.log('可用命令:');
      console.log('  hexo robot-version set <version> [description]  - 设置版本信息');
      console.log('  hexo robot-version get                          - 获取当前版本信息');
      break;
  }
});
'''
    
    hexo_plugin_file = api_dir / "robot_ota_plugin.js"
    with open(hexo_plugin_file, 'w', encoding='utf-8') as f:
        f.write(hexo_plugin)
    print(f"✅ 已创建Hexo插件: {hexo_plugin_file}")
    
    # 5. 创建使用说明
    usage_guide = '''# Hexo Robot OTA API 设置指南

## 快速设置步骤

### 1. 复制文件到Hexo网站

```bash
# 复制API文件到hexo网站的source目录
cp hexo_api/version.md /path/to/your/hexo/site/source/api/
cp hexo_api/robot_ota_plugin.js /path/to/your/hexo/site/scripts/
cp hexo_api/deploy_robot_version.sh /path/to/your/hexo/site/

# 创建下载目录
mkdir -p /path/to/your/hexo/site/source/downloads
```

### 2. 生成静态文件

```bash
cd /path/to/your/hexo/site
hexo generate
```

### 3. 部署到服务器

```bash
hexo deploy
```

## 使用方法

### 设置版本信息

```bash
# 使用Hexo命令
hexo robot-version set 1.0.0 "初始版本"

# 或使用部署脚本
./deploy_robot_version.sh 1.0.0 "初始版本" robot_v1.0.0.zip
```

### 查看版本信息

```bash
hexo robot-version get
```

## API端点

- 版本信息: `http://192.168.139.134:4000/api/version.json`
- 下载目录: `http://192.168.139.134:4000/downloads/`

## 注意事项

1. 确保hexo网站已正确配置并运行
2. 版本包文件名必须与version.json中的filename字段一致
3. 每次更新版本后都要运行 `hexo generate` 重新生成静态文件
4. 建议保留多个版本的备份文件

## 故障排除

如果API无法访问：
1. 检查文件是否正确复制到source目录
2. 确认运行了 `hexo generate`
3. 检查hexo网站是否正常运行
4. 验证文件权限设置
'''
    
    usage_guide_file = api_dir / "README.md"
    with open(usage_guide_file, 'w', encoding='utf-8') as f:
        f.write(usage_guide)
    print(f"✅ 已创建使用说明: {usage_guide_file}")
    
    print(f"\n🎉 所有文件已创建完成！")
    print(f"请查看 {api_dir}/README.md 了解详细的使用方法")


def main():
    """主函数"""
    print("Hexo Robot OTA API 设置工具")
    print("=" * 40)
    
    create_api_files()


if __name__ == "__main__":
    main()
