#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OTA启动脚本
提供简单的命令行界面来管理OTA更新
"""

import os
import sys
import time
import signal
import argparse
import threading
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, str(Path(__file__).parent))

from ota_updater import OTAManager
from version_manager import VersionManager


class OTAController:
    """OTA控制器"""
    
    def __init__(self):
        self.ota_manager = OTAManager()
        self.version_manager = VersionManager()
        self.running = False
        self.check_thread = None
        
    def signal_handler(self, signum, frame):
        """信号处理器"""
        print(f"\n收到信号 {signum}，正在停止OTA服务...")
        self.running = False
        if self.check_thread and self.check_thread.is_alive():
            self.check_thread.join(timeout=5)
        sys.exit(0)
    
    def check_updates_loop(self):
        """检查更新循环"""
        check_interval = self.ota_manager.config.get('check_interval', 3600)
        
        while self.running:
            try:
                print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] 检查版本更新...")
                success = self.ota_manager.check_and_update()
                
                if success:
                    print("版本检查完成")
                else:
                    print("版本检查失败，请查看日志")
                
            except Exception as e:
                print(f"检查更新时发生错误: {e}")
            
            # 等待下次检查
            for _ in range(check_interval):
                if not self.running:
                    break
                time.sleep(1)
    
    def start_daemon(self):
        """启动守护进程"""
        print("启动OTA守护进程...")
        self.running = True
        
        # 注册信号处理器
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        # 启动检查线程
        self.check_thread = threading.Thread(target=self.check_updates_loop)
        self.check_thread.daemon = True
        self.check_thread.start()
        
        print(f"OTA守护进程已启动，检查间隔: {self.ota_manager.config.get('check_interval', 3600)}秒")
        print("按 Ctrl+C 停止服务")
        
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        
        self.running = False
        print("OTA守护进程已停止")
    
    def check_once(self):
        """执行一次版本检查"""
        print("执行版本检查...")
        success = self.ota_manager.check_and_update()
        
        if success:
            print("版本检查完成")
            status = self.ota_manager.get_status()
            print(f"当前版本: {status['current_version']['version']}")
        else:
            print("版本检查失败，请查看日志")
        
        return success
    
    def create_version(self, version, description="", create_package=False):
        """创建版本"""
        print(f"创建版本: {version}")
        
        version_info = self.version_manager.create_version_info(version, description)
        
        print(f"版本信息:")
        print(f"  版本号: {version_info['version']}")
        print(f"  文件数量: {version_info['file_count']}")
        print(f"  总大小: {version_info['total_size']} bytes")
        print(f"  校验和: {version_info['checksum']}")
        
        # 保存版本信息
        self.version_manager.save_version_info(version_info)
        
        # 创建包
        if create_package:
            package_path = self.version_manager.create_package(version_info)
            if package_path:
                print(f"版本包已创建: {package_path}")
                return package_path
        
        return None
    
    def show_status(self):
        """显示状态信息"""
        status = self.ota_manager.get_status()
        
        print("=== OTA状态信息 ===")
        print(f"当前版本: {status['current_version']['version']}")
        print(f"构建日期: {status['current_version'].get('build_date', 'N/A')}")
        print(f"版本描述: {status['current_version'].get('description', 'N/A')}")
        print(f"Hexo URL: {status['config']['hexo_url']}")
        print(f"检查间隔: {status['config']['check_interval']}秒")
        print(f"最后检查: {status['last_check']}")
        
        # 显示版本历史
        history = self.version_manager.get_version_history()
        if history:
            print(f"\n版本历史 (最近{min(5, len(history))}个):")
            for i, version_info in enumerate(history[:5]):
                print(f"  {i+1}. {version_info['version']} - {version_info.get('description', '')}")
    
    def list_backups(self):
        """列出备份"""
        backup_dir = self.ota_manager.backup_dir
        
        if not backup_dir.exists():
            print("备份目录不存在")
            return
        
        backups = list(backup_dir.glob("backup_*"))
        if not backups:
            print("没有找到备份")
            return
        
        print("可用备份:")
        backups.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        
        for i, backup in enumerate(backups):
            stat = backup.stat()
            mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_mtime))
            print(f"  {i+1}. {backup.name} ({mtime})")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="Robot OTA更新控制器")
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 检查更新命令
    subparsers.add_parser('check', help='执行一次版本检查')
    
    # 守护进程命令
    subparsers.add_parser('daemon', help='启动守护进程')
    
    # 创建版本命令
    create_parser = subparsers.add_parser('create', help='创建版本')
    create_parser.add_argument('version', help='版本号')
    create_parser.add_argument('-d', '--description', help='版本描述', default='')
    create_parser.add_argument('-p', '--package', action='store_true', help='创建版本包')
    
    # 状态命令
    subparsers.add_parser('status', help='显示状态信息')
    
    # 备份命令
    subparsers.add_parser('backups', help='列出备份')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    controller = OTAController()
    
    try:
        if args.command == 'check':
            controller.check_once()
        elif args.command == 'daemon':
            controller.start_daemon()
        elif args.command == 'create':
            controller.create_version(args.version, args.description, args.package)
        elif args.command == 'status':
            controller.show_status()
        elif args.command == 'backups':
            controller.list_backups()
    except KeyboardInterrupt:
        print("\n操作被用户中断")
    except Exception as e:
        print(f"操作失败: {e}")


if __name__ == "__main__":
    main()
