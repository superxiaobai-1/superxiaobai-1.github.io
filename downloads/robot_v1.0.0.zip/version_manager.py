#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
版本管理器
用于管理robot代码的版本信息
"""

import json
import os
import hashlib
import zipfile
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime


class VersionManager:
    """版本管理器"""
    
    def __init__(self, workspace_path: str = None):
        """
        初始化版本管理器
        
        Args:
            workspace_path: 工作空间路径
        """
        if workspace_path is None:
            workspace_path = Path(__file__).parent
        
        self.workspace_path = Path(workspace_path)
        self.version_file = self.workspace_path / "version.json"
        self.history_file = self.workspace_path / "version_history.json"
        
    def get_current_version(self) -> Dict:
        """获取当前版本信息"""
        if self.version_file.exists():
            try:
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"读取版本文件失败: {e}")
        
        # 返回默认版本
        return {
            "version": "0.0.0",
            "build_date": datetime.now().isoformat(),
            "checksum": "",
            "description": "初始版本",
            "files": []
        }
    
    def create_version_info(self, version: str, description: str = "", 
                          exclude_patterns: List[str] = None) -> Dict:
        """
        创建版本信息
        
        Args:
            version: 版本号
            description: 版本描述
            exclude_patterns: 排除的文件模式
            
        Returns:
            版本信息字典
        """
        if exclude_patterns is None:
            exclude_patterns = [
                '*.log', 'temp', 'backup', '__pycache__', '*.pyc',
                'version.json', 'version_history.json', 'ota_config.json',
                'node_modules', '.git', '.vscode', '.idea'
            ]
        
        # 扫描文件
        files_info = self._scan_files(exclude_patterns)
        
        # 计算总体校验和
        total_checksum = self._calculate_total_checksum(files_info)
        
        version_info = {
            "version": version,
            "build_date": datetime.now().isoformat(),
            "checksum": total_checksum,
            "description": description,
            "files": files_info,
            "file_count": len(files_info),
            "total_size": sum(f['size'] for f in files_info)
        }
        
        return version_info
    
    def _scan_files(self, exclude_patterns: List[str]) -> List[Dict]:
        """扫描文件并获取信息"""
        files_info = []
        
        def should_exclude(file_path: Path) -> bool:
            """检查文件是否应该被排除"""
            file_str = str(file_path)
            for pattern in exclude_patterns:
                if pattern.startswith('*'):
                    if file_str.endswith(pattern[1:]):
                        return True
                elif pattern in file_str:
                    return True
            return False
        
        for file_path in self.workspace_path.rglob('*'):
            if file_path.is_file() and not should_exclude(file_path):
                relative_path = file_path.relative_to(self.workspace_path)
                
                file_info = {
                    "path": str(relative_path),
                    "size": file_path.stat().st_size,
                    "modified": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
                    "checksum": self._calculate_file_checksum(file_path)
                }
                files_info.append(file_info)
        
        return files_info
    
    def _calculate_file_checksum(self, file_path: Path) -> str:
        """计算单个文件的校验和"""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)
            return sha256_hash.hexdigest()
        except Exception as e:
            print(f"计算文件校验和失败 {file_path}: {e}")
            return ""
    
    def _calculate_total_checksum(self, files_info: List[Dict]) -> str:
        """计算总体校验和"""
        sha256_hash = hashlib.sha256()
        
        # 按文件路径排序确保一致性
        sorted_files = sorted(files_info, key=lambda x: x['path'])
        
        for file_info in sorted_files:
            # 将文件信息转换为字符串并计算校验和
            file_data = f"{file_info['path']}:{file_info['checksum']}:{file_info['size']}"
            sha256_hash.update(file_data.encode('utf-8'))
        
        return sha256_hash.hexdigest()
    
    def save_version_info(self, version_info: Dict):
        """保存版本信息"""
        try:
            # 保存当前版本
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump(version_info, f, indent=2, ensure_ascii=False)
            
            # 保存到历史记录
            self._add_to_history(version_info)
            
            print(f"版本信息已保存: {version_info['version']}")
            
        except Exception as e:
            print(f"保存版本信息失败: {e}")
    
    def _add_to_history(self, version_info: Dict):
        """添加到历史记录"""
        history = self.get_version_history()
        
        # 添加新版本到历史记录
        history.append(version_info)
        
        # 按版本号排序（这里简化处理，实际应该用语义化版本比较）
        history.sort(key=lambda x: x['version'], reverse=True)
        
        # 只保留最近的20个版本
        if len(history) > 20:
            history = history[:20]
        
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(history, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存版本历史失败: {e}")
    
    def get_version_history(self) -> List[Dict]:
        """获取版本历史"""
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"读取版本历史失败: {e}")
        
        return []
    
    def create_package(self, version_info: Dict, output_path: str = None) -> str:
        """
        创建版本包
        
        Args:
            version_info: 版本信息
            output_path: 输出路径
            
        Returns:
            创建的包文件路径
        """
        if output_path is None:
            output_path = self.workspace_path / f"robot_v{version_info['version']}.zip"
        
        output_path = Path(output_path)
        
        try:
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file_info in version_info['files']:
                    file_path = self.workspace_path / file_info['path']
                    if file_path.exists():
                        # 使用相对路径添加到zip
                        zipf.write(file_path, file_info['path'])
            
            print(f"版本包已创建: {output_path}")
            return str(output_path)
            
        except Exception as e:
            print(f"创建版本包失败: {e}")
            return ""
    
    def verify_package(self, package_path: str) -> bool:
        """
        验证版本包
        
        Args:
            package_path: 包文件路径
            
        Returns:
            验证是否成功
        """
        package_path = Path(package_path)
        
        if not package_path.exists():
            print(f"包文件不存在: {package_path}")
            return False
        
        try:
            # 解压到临时目录进行验证
            import tempfile
            with tempfile.TemporaryDirectory() as temp_dir:
                with zipfile.ZipFile(package_path, 'r') as zipf:
                    zipf.extractall(temp_dir)
                
                # 验证文件完整性
                temp_path = Path(temp_dir)
                for file_path in temp_path.rglob('*'):
                    if file_path.is_file():
                        # 这里可以添加更详细的验证逻辑
                        pass
                
                print("包文件验证成功")
                return True
                
        except Exception as e:
            print(f"包文件验证失败: {e}")
            return False


def main():
    """主函数 - 用于创建版本包"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Robot版本管理器")
    parser.add_argument("version", help="版本号")
    parser.add_argument("-d", "--description", help="版本描述", default="")
    parser.add_argument("-o", "--output", help="输出包文件路径")
    parser.add_argument("--create-package", action="store_true", help="创建版本包")
    
    args = parser.parse_args()
    
    version_manager = VersionManager()
    
    # 创建版本信息
    version_info = version_manager.create_version_info(args.version, args.description)
    
    print(f"版本信息:")
    print(f"  版本号: {version_info['version']}")
    print(f"  文件数量: {version_info['file_count']}")
    print(f"  总大小: {version_info['total_size']} bytes")
    print(f"  校验和: {version_info['checksum']}")
    
    # 保存版本信息
    version_manager.save_version_info(version_info)
    
    # 创建包
    if args.create_package:
        package_path = version_manager.create_package(version_info, args.output)
        if package_path:
            # 验证包
            version_manager.verify_package(package_path)


if __name__ == "__main__":
    main()
