#!/bin/bash
# deploy_robot_version.sh - Robot版本部署脚本

VERSION=$1
DESCRIPTION=$2
PACKAGE_FILE=$3

if [ -z "$VERSION" ] || [ -z "$PACKAGE_FILE" ]; then
    echo "用法: $0 <版本号> <描述> <包文件>"
    echo "示例: $0 1.1.0 '新功能版本' robot_v1.1.0.zip"
    exit 1
fi

# 检查包文件是否存在
if [ ! -f "$PACKAGE_FILE" ]; then
    echo "错误: 包文件不存在: $PACKAGE_FILE"
    exit 1
fi

# 计算文件校验和
CHECKSUM=$(sha256sum "$PACKAGE_FILE" | cut -d' ' -f1)

# 创建版本信息JSON
cat > source/api/version.md << EOF
---
title: Robot版本信息API
date: $(date -u +%Y-%m-%dT%H:%M:%S)
layout: false
---
{
  "version": "$VERSION",
  "build_date": "$(date -u +%Y-%m-%dT%H:%M:%S)",
  "checksum": "$CHECKSUM",
  "description": "$DESCRIPTION",
  "filename": "$PACKAGE_FILE"
}
EOF

# 创建下载目录（如果不存在）
mkdir -p source/downloads

# 复制包文件到下载目录
cp "$PACKAGE_FILE" source/downloads/

echo "版本 $VERSION 已部署"
echo "校验和: $CHECKSUM"
echo "请运行 'hexo generate' 生成静态文件"
