/**
 * Hexo Robot OTA API 插件
 * 自动生成Robot版本信息API
 */

const fs = require('fs');
const path = require('path');

hexo.extend.generator.register('robot_api', function(locals) {
  const apiDir = path.join(hexo.source_dir, 'api');
  
  return [
    {
      path: 'api/version.json',
      data: function() {
        // 读取版本信息
        const versionFile = path.join(apiDir, 'version.json');
        let versionInfo = {
          version: "1.0.0",
          build_date: new Date().toISOString(),
          checksum: "",
          description: "初始版本",
          filename: "robot_v1.0.0.zip"
        };

        if (fs.existsSync(versionFile)) {
          try {
            const content = fs.readFileSync(versionFile, 'utf8');
            versionInfo = JSON.parse(content);
          } catch (error) {
            console.error('读取版本信息失败:', error);
          }
        }

        return versionInfo;
      },
      layout: false
    }
  ];
});

// 命令行工具
hexo.extend.console.register('robot-version', '管理Robot版本信息', {
  usage: '[command] [options]',
  arguments: [
    {name: 'command', desc: '命令: set, get'},
    {name: 'version', desc: '版本号'},
    {name: 'description', desc: '版本描述'}
  ]
}, function(args) {
  const command = args._.shift();
  const versionFile = path.join(hexo.source_dir, 'api', 'version.json');
  
  switch (command) {
    case 'set':
      const version = args.version || args._.shift();
      const description = args.description || args._.shift() || '新版本';
      
      if (!version) {
        console.log('请指定版本号');
        return;
      }

      const versionInfo = {
        version: version,
        build_date: new Date().toISOString(),
        checksum: "sha256_checksum_here",
        description: description,
        filename: `robot_v${version}.zip`
      };

      try {
        // 确保目录存在
        const apiDir = path.dirname(versionFile);
        if (!fs.existsSync(apiDir)) {
          fs.mkdirSync(apiDir, { recursive: true });
        }
        
        fs.writeFileSync(versionFile, JSON.stringify(versionInfo, null, 2));
        console.log(`版本信息已更新: ${version}`);
      } catch (error) {
        console.error('更新版本信息失败:', error);
      }
      break;

    case 'get':
      try {
        if (fs.existsSync(versionFile)) {
          const content = fs.readFileSync(versionFile, 'utf8');
          const versionInfo = JSON.parse(content);
          console.log('当前版本信息:');
          console.log(JSON.stringify(versionInfo, null, 2));
        } else {
          console.log('版本信息文件不存在');
        }
      } catch (error) {
        console.error('读取版本信息失败:', error);
      }
      break;

    default:
      console.log('可用命令:');
      console.log('  hexo robot-version set <version> [description]  - 设置版本信息');
      console.log('  hexo robot-version get                          - 获取当前版本信息');
      break;
  }
});
