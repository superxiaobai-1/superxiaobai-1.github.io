# Hexo Robot OTA API 设置指南

## 快速设置步骤

### 1. 复制文件到Hexo网站

```bash
# 复制API文件到hexo网站的source目录
cp hexo_api/version.md /path/to/your/hexo/site/source/api/
cp hexo_api/robot_ota_plugin.js /path/to/your/hexo/site/scripts/
cp hexo_api/deploy_robot_version.sh /path/to/your/hexo/site/

# 创建下载目录
mkdir -p /path/to/your/hexo/site/source/downloads
```

### 2. 生成静态文件

```bash
cd /path/to/your/hexo/site
hexo generate
```

### 3. 部署到服务器

```bash
hexo deploy
```

## 使用方法

### 设置版本信息

```bash
# 使用Hexo命令
hexo robot-version set 1.0.0 "初始版本"

# 或使用部署脚本
./deploy_robot_version.sh 1.0.0 "初始版本" robot_v1.0.0.zip
```

### 查看版本信息

```bash
hexo robot-version get
```

## API端点

- 版本信息: `http://192.168.139.134:4000/api/version.json`
- 下载目录: `http://192.168.139.134:4000/downloads/`

## 注意事项

1. 确保hexo网站已正确配置并运行
2. 版本包文件名必须与version.json中的filename字段一致
3. 每次更新版本后都要运行 `hexo generate` 重新生成静态文件
4. 建议保留多个版本的备份文件

## 故障排除

如果API无法访问：
1. 检查文件是否正确复制到source目录
2. 确认运行了 `hexo generate`
3. 检查hexo网站是否正常运行
4. 验证文件权限设置
