---
title: Robot版本信息API
date: 2024-01-01 00:00:00
layout: false
---
{
  "version": "1.0.0",
  "build_date": "2024-01-15T10:30:00",
  "checksum": "sha256_example_checksum_here",
  "description": "初始版本",
  "filename": "robot_v1.0.0.zip"
}