# Robot下载目录

此目录用于存放robot代码压缩包。

## 文件命名规则
- 格式: `robot_v{版本号}.zip`
- 示例: `robot_v1.0.0.zip`, `robot_v1.1.0.zip`

## 上传步骤
1. 使用版本管理器创建版本包
2. 将zip文件上传到此目录
3. 更新 `/api/version` 中的版本信息

## 注意事项
- 确保文件名与version.json中的filename字段一致
- 建议保留多个版本的备份文件
